# Tableau TWB TypeScript tools

This folder contains:

- `src/patch-twb.ts`: applies a JSON config to a `.twb`
- `src/extract-config.ts`: extracts a starter JSON config from an existing `.twb`
- `configs/daily-diagnostics.extracted.json`: starter config generated from your attached workbook

## Local setup

This project is pinned to `fast-xml-parser@5.8.0`.

```bash
cd twb-typescript
npm install
npm run build
```

## Extract a starter config from a workbook

```bash
npm run extract-config -- /absolute/path/to/Daily\ Diagnostics.twb ./configs/from-workbook.json
```

## Patch a workbook from config

```bash
npm run patch -- ./configs/daily-diagnostics.extracted.json /absolute/path/to/template.twb ./output.twb
```

## What the patcher currently supports

- updating parameter defaults
- replacing parameter member lists
- updating simple renamed-field formulas like `[customDimension3]`
- updating CASE-based parameter-dimension calcs such as `Select Dimension`, `Select Dimension 2`, etc.
- optionally updating datasource `repository-location.path` values when provided in config

## Notes

- The config format is JSON to keep local setup simple.
- The extractor is heuristic-based for Tableau XML; it is designed to produce a strong starter config, not a perfect semantic model of every workbook pattern.
