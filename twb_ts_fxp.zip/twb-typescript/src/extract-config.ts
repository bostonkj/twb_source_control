import fs from 'node:fs';
import path from 'node:path';
import { XMLParser } from 'fast-xml-parser';

type ParameterExtract = {
  workbookName: string;
  defaultValue?: string;
  allowedValues: string[];
};

type ExtractedConfig = {
  template: {
    reportName: string;
    sourceWorkbook: string;
    generatedAt: string;
  };
  datasourcePaths: Array<{
    workbookName: string;
    path: string;
  }>;
  parameters: Record<string, ParameterExtract>;
  renamedFields: Record<string, {
    workbookName: string;
    formula: string;
  }>;
  parameterDimensions: Record<string, {
    workbookName: string;
    parameterCaption: string;
    cases: Record<string, string>;
  }>;
};

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  preserveOrder: false,
  trimValues: false,
  processEntities: false,
});

function asArray<T>(value: T | T[] | undefined): T[] {
  if (value === undefined) return [];
  return Array.isArray(value) ? value : [value];
}

function stripBrackets(value: string | undefined): string {
  return (value ?? '').replace(/^\[/, '').replace(/\]$/, '');
}

function unquoteParameterValue(value: string | undefined): string | undefined {
  if (!value) return value;
  if (value.startsWith('"') && value.endsWith('"')) return value.slice(1, -1);
  return value;
}

function parseMembers(column: any): string[] {
  return asArray(column?.members?.member)
    .map((member) => unquoteParameterValue(member?.['@_value']))
    .filter((value): value is string => Boolean(value));
}

function getDatasources(doc: any): any[] {
  return asArray(doc?.workbook?.datasources?.datasource);
}

function getColumns(container: any): any[] {
  return asArray(container?.column);
}

function getFolders(container: any): any[] {
  return asArray(container?.folder);
}

function folderItemNames(folder: any): string[] {
  return asArray(folder?.['folder-item']).map((item) => stripBrackets(item?.['@_name']));
}

function findParameterDatasource(doc: any): any | undefined {
  return getDatasources(doc).find((ds) => ds?.['@_name'] === 'Parameters' || ds?.['@_formatted-name'] === 'Parameters');
}

function findColumnsAcrossDatasources(doc: any): any[] {
  return getDatasources(doc).flatMap((ds) => getColumns(ds));
}

function findColumnByNameOrCaption(doc: any, key: string): any | undefined {
  return findColumnsAcrossDatasources(doc).find((col) => col?.['@_caption'] === key || stripBrackets(col?.['@_name']) === key);
}

function parseCaseFormula(formula: string): { parameterWorkbookName: string; cases: Record<string, string> } | null {
  const headerMatch = formula.match(/CASE\s+\[Parameters\]\.\[([^\]]+)\]/i);
  if (!headerMatch) return null;
  const cases: Record<string, string> = {};
  const lines = formula.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (const line of lines) {
    const whenMatch = line.match(/^WHEN\s+"([^"]+)"\s+THEN\s+(.+)$/i);
    if (whenMatch) {
      cases[whenMatch[1]] = whenMatch[2].trim();
    }
  }
  return { parameterWorkbookName: headerMatch[1], cases };
}

function extractParameters(doc: any): Record<string, ParameterExtract> {
  const ds = findParameterDatasource(doc);
  if (!ds) return {};
  const result: Record<string, ParameterExtract> = {};
  for (const column of getColumns(ds)) {
    const caption = column?.['@_caption'];
    if (!caption) continue;
    const members = parseMembers(column);
    const defaultValue = unquoteParameterValue(column?.['@_value']);
    result[caption] = {
      workbookName: stripBrackets(column?.['@_name']),
      defaultValue,
      allowedValues: members,
    };
  }
  return result;
}

function extractDatasourcePaths(doc: any): Array<{ workbookName: string; path: string }> {
  return getDatasources(doc)
    .flatMap((ds) => asArray(ds?.['repository-location']).map((repo) => ({
      workbookName: ds?.['@_name'] ?? ds?.['@_formatted-name'] ?? '',
      path: repo?.['@_path'] ?? '',
    })))
    .filter((entry) => entry.workbookName && entry.path);
}

function extractRenamedFields(doc: any): Record<string, { workbookName: string; formula: string }> {
  const result: Record<string, { workbookName: string; formula: string }> = {};
  const renamedCandidates = findColumnsAcrossDatasources(doc)
    .filter((column) => {
      const caption = column?.['@_caption'];
      const formula = column?.calculation?.['@_formula'];
      if (!caption || !formula) return false;
      return /^\[[^\]]+\]$/.test(formula) && caption !== stripBrackets(formula);
    });

  for (const column of renamedCandidates) {
    const caption = column['@_caption'];
    result[caption] = {
      workbookName: stripBrackets(column?.['@_name']),
      formula: column?.calculation?.['@_formula'],
    };
  }
  return result;
}

function extractParameterDimensions(doc: any, parameters: Record<string, ParameterExtract>): Record<string, { workbookName: string; parameterCaption: string; cases: Record<string, string> }> {
  const result: Record<string, { workbookName: string; parameterCaption: string; cases: Record<string, string> }> = {};
  for (const column of findColumnsAcrossDatasources(doc)) {
    const caption = column?.['@_caption'];
    const workbookName = stripBrackets(column?.['@_name']);
    const formula = column?.calculation?.['@_formula'];
    if (!caption || !formula || !/^Select Dimension/.test(caption)) continue;
    const parsed = parseCaseFormula(formula);
    if (!parsed) continue;
    const parameterCaption = Object.entries(parameters).find(([, value]) => value.workbookName === parsed.parameterWorkbookName)?.[0] ?? parsed.parameterWorkbookName;
    result[caption] = {
      workbookName,
      parameterCaption,
      cases: parsed.cases,
    };
  }
  return result;
}

function main(): void {
  const [, , twbPath, outputPath] = process.argv;
  if (!twbPath || !outputPath) {
    console.error('Usage: node dist/src/extract-config.js <input.twb> <output.json>');
    process.exit(1);
  }

  const rawXml = fs.readFileSync(twbPath, 'utf8');
  const doc = parser.parse(rawXml);
  const parameters = extractParameters(doc);

  const config: ExtractedConfig = {
    template: {
      reportName: path.basename(twbPath),
      sourceWorkbook: path.resolve(twbPath),
      generatedAt: new Date().toISOString(),
    },
    datasourcePaths: extractDatasourcePaths(doc),
    parameters,
    renamedFields: extractRenamedFields(doc),
    parameterDimensions: extractParameterDimensions(doc, parameters),
  };

  fs.writeFileSync(outputPath, JSON.stringify(config, null, 2) + '\n', 'utf8');
  console.log(`Starter config written to ${path.resolve(outputPath)}`);
}

main();
