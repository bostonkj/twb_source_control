import fs from 'node:fs';
import path from 'node:path';
import { XMLParser, XMLBuilder } from 'fast-xml-parser';

type ParameterConfig = {
  workbookName?: string;
  defaultValue?: string;
  allowedValues?: string[];
};

type RenamedFieldConfig = {
  workbookName?: string;
  formula: string;
};

type ParameterDimensionCaseMap = Record<string, string>;

type ParameterDimensionConfig = {
  workbookName?: string;
  parameterCaption: string;
  cases: ParameterDimensionCaseMap;
};

type DatasourcePathConfig = {
  workbookName: string;
  path: string;
};

type TwbConfig = {
  template?: {
    reportName?: string;
    sourceWorkbook?: string;
    generatedAt?: string;
  };
  datasourcePaths?: DatasourcePathConfig[];
  parameters?: Record<string, ParameterConfig>;
  renamedFields?: Record<string, RenamedFieldConfig>;
  parameterDimensions?: Record<string, ParameterDimensionConfig>;
};

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  preserveOrder: false,
  trimValues: false,
  processEntities: false,
});

const builder = new XMLBuilder({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  preserveOrder: false,
  format: true,
  suppressEmptyNode: false,
});

function asArray<T>(value: T | T[] | undefined): T[] {
  if (value === undefined) return [];
  return Array.isArray(value) ? value : [value];
}

function readJson<T>(filePath: string): T {
  return JSON.parse(fs.readFileSync(filePath, 'utf8')) as T;
}

function readXml(filePath: string): any {
  return parser.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeXml(filePath: string, doc: any): void {
  fs.writeFileSync(filePath, builder.build(doc), 'utf8');
}

function getDatasources(doc: any): any[] {
  return asArray(doc?.workbook?.datasources?.datasource);
}

function getColumns(container: any): any[] {
  return asArray(container?.column);
}

function getFolders(container: any): any[] {
  return asArray(container?.folder);
}

function folderItems(folder: any): any[] {
  return asArray(folder?.['folder-item']);
}

function firstString(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined;
}

function findParameterDatasource(doc: any): any | undefined {
  return getDatasources(doc).find((ds) => ds?.['@_name'] === 'Parameters' || ds?.['@_formatted-name'] === 'Parameters');
}

function findColumnByCaptionAcrossDatasources(doc: any, caption: string): any | undefined {
  for (const ds of getDatasources(doc)) {
    const match = getColumns(ds).find((col) => col?.['@_caption'] === caption);
    if (match) return match;
  }
  return undefined;
}

function findParameterByCaption(doc: any, caption: string): any | undefined {
  const ds = findParameterDatasource(doc);
  if (!ds) return undefined;
  return getColumns(ds).find((col) => col?.['@_caption'] === caption);
}

function ensureMembersNode(column: any): any {
  if (!column.members) column.members = {};
  return column.members;
}

function setParameterMembers(column: any, values: string[]): void {
  const membersNode = ensureMembersNode(column);
  membersNode.member = values.map((value) => ({ '@_value': JSON.stringify(value) }));
}

function setParameterDefault(column: any, value: string): void {
  column['@_value'] = JSON.stringify(value);
  if (column.calculation) {
    column.calculation['@_formula'] = JSON.stringify(value);
  }
}

function setCalculationFormula(column: any, formula: string): void {
  if (!column.calculation) column.calculation = {};
  column.calculation['@_formula'] = formula;
}

function buildCaseFormula(parameterWorkbookName: string, cases: Record<string, string>): string {
  const lines = [`CASE [Parameters].[${parameterWorkbookName}]`];
  for (const [label, expr] of Object.entries(cases)) {
    lines.push(`    WHEN ${JSON.stringify(label)} THEN ${expr}`);
  }
  lines.push('END');
  return lines.join('\r\n');
}

function updateDatasourcePaths(doc: any, config: TwbConfig): void {
  for (const pathConfig of config.datasourcePaths ?? []) {
    const ds = getDatasources(doc).find((candidate) => candidate?.['@_name'] === pathConfig.workbookName || candidate?.['@_formatted-name'] === pathConfig.workbookName);
    if (!ds) continue;
    const repoLocations = asArray(ds['repository-location']);
    for (const repo of repoLocations) {
      repo['@_path'] = pathConfig.path;
    }
  }
}

function applyParameters(doc: any, config: TwbConfig): void {
  for (const [caption, parameterConfig] of Object.entries(config.parameters ?? {})) {
    const column = findParameterByCaption(doc, caption);
    if (!column) continue;
    if (parameterConfig.allowedValues && parameterConfig.allowedValues.length > 0) {
      setParameterMembers(column, parameterConfig.allowedValues);
    }
    if (parameterConfig.defaultValue !== undefined) {
      setParameterDefault(column, parameterConfig.defaultValue);
    }
  }
}

function applyRenamedFields(doc: any, config: TwbConfig): void {
  for (const [caption, fieldConfig] of Object.entries(config.renamedFields ?? {})) {
    const column = findColumnByCaptionAcrossDatasources(doc, caption);
    if (!column) continue;
    setCalculationFormula(column, fieldConfig.formula);
  }
}

function applyParameterDimensions(doc: any, config: TwbConfig): void {
  for (const [caption, dimensionConfig] of Object.entries(config.parameterDimensions ?? {})) {
    const column = findColumnByCaptionAcrossDatasources(doc, caption);
    if (!column) continue;
    const parameterName = dimensionConfig.workbookName ?? findParameterByCaption(doc, dimensionConfig.parameterCaption)?.['@_name']?.replace(/^\[|\]$/g, '') ?? dimensionConfig.parameterCaption;
    setCalculationFormula(column, buildCaseFormula(parameterName, dimensionConfig.cases));
  }
}

function main(): void {
  const [, , configPath, templatePath, outputPath] = process.argv;
  if (!configPath || !templatePath || !outputPath) {
    console.error('Usage: node dist/src/patch-twb.js <config.json> <template.twb> <output.twb>');
    process.exit(1);
  }

  const config = readJson<TwbConfig>(configPath);
  const doc = readXml(templatePath);

  updateDatasourcePaths(doc, config);
  applyParameters(doc, config);
  applyRenamedFields(doc, config);
  applyParameterDimensions(doc, config);

  writeXml(outputPath, doc);
  console.log(`Patched workbook written to ${path.resolve(outputPath)}`);
}

main();
